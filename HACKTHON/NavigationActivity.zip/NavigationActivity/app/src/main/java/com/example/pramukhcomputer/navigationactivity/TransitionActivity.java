package com.example.pramukhcomputer.navigationactivity;

import android.graphics.drawable.TransitionDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class TransitionActivity extends AppCompatActivity {

    ImageView imageView;
    Button btnSwitch;

    boolean turnedOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transition);

        imageView = (ImageView) findViewById(R.id.imageView);
        btnSwitch = (Button)findViewById(R.id.btnSwitch);
        btnSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!turnedOn) {
                    imageView.setImageResource(R.drawable.trans_on);
                    ((TransitionDrawable) imageView.getDrawable()).startTransition(3000);
                    Log.d("ABC", "done!");
                    turnedOn = true;
                    //imageView.setImageResource(R.drawable.scary);
                }else
                {
                    imageView.setImageResource(R.drawable.scary);
                    turnedOn = false;
                }

            }
        });


    }
}
