package com.example.pramukhcomputer.navigationactivity;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import pl.droidsonroids.gif.GifImageView;

public class AngrypunchActivity extends AppCompatActivity implements View.OnClickListener{
    ImageButton btnpunch;
    GifImageView gifpunch;
    int i = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_angrypunch);

        gifpunch = findViewById(R.id.gifpunch);
        btnpunch = findViewById(R.id.btnpunch);
        btnpunch.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        i++;
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(i == 1)
                {
                    Toast.makeText(AngrypunchActivity.this,"Single click",Toast.LENGTH_SHORT).show();
                }
                else if(i ==2)
                {
                    Toast.makeText(AngrypunchActivity.this,"Double click",Toast.LENGTH_SHORT).show();
                }
                i=0;
            }

        },500);
    }
    }

