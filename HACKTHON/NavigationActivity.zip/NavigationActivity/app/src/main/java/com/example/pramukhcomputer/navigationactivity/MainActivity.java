package com.example.pramukhcomputer.navigationactivity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    CanvasView canvasView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        canvasView = (CanvasView)findViewById(R.id.mycanvas);
    }

    public void clearCanvas(View v)
    {
        canvasView.clearCanvas();
    }
}
