package com.example.pramukhcomputer.navigationactivity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HappyActivity extends AppCompatActivity implements View.OnClickListener{

    TextView display;
    int count = 0;
    Button counter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_happy);

        display = findViewById(R.id.display);

        counter = findViewById(R.id.counter);
        counter.setOnClickListener(this);
    }

    public void count(View view)
    {
        count++;
        display.setText(Integer.toString(count));
    }

    @Override
    public void onClick(View view) {
                startActivity(new Intent(this,MainActivity.class));
    }
}
