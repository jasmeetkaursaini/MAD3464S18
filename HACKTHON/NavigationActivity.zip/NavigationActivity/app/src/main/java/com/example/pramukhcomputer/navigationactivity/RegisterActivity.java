package com.example.pramukhcomputer.navigationactivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    TextView text1,text2,text3,text4;
    Button btnRegister;
    EditText edtName,edtOne,edtTwo ;
    DBHelper dbHelper;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edtName = findViewById(R.id.edtName);
        edtOne = findViewById(R.id.edtone);
        edtTwo = findViewById(R.id.edttwo);



        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == btnRegister.getId()){
            insertData();
            displayData();

            finish();
            startActivity(new Intent(this,HomeActivity.class));

        }

    }

    private void insertData() {

        try{
            ContentValues cv = new ContentValues();
            cv.put("Name",edtName.getText().toString());

            cv.put("Aone",edtOne.getText().toString());
            cv.put("Atwo",edtTwo.getText().toString());


            sqLiteDatabase = dbHelper.getWritableDatabase();
            sqLiteDatabase.insert("TouristInfo", null,cv);

            Log.v("RegisterActivity","User Account Created");

        }catch(Exception e){
            Log.e("RegisterActivity",e.getMessage());
        }finally {
            sqLiteDatabase.close();
        }
    }

    private void displayData(){
        try{
            sqLiteDatabase = dbHelper.getReadableDatabase();
            String columns[] = {"Name", "Aone", "Atwo"};

            Cursor cursor = sqLiteDatabase.query("TouristInfo",columns,
                    null,null,null, null, null);

            while (cursor.moveToNext()){
                String userData = cursor.getString(cursor.getColumnIndex("Name"));
                userData += "\n" + cursor.getString(cursor.getColumnIndex("Aone"));
                //userData += "\n" + cursor.getString(cursor.getColumnIndex("Password"));
                userData += "\n" + cursor.getString(cursor.getColumnIndex("Atwo"));

                Toast.makeText(this, userData,Toast.LENGTH_LONG).show();
            }

        }catch(Exception e){
            Log.e("RegisterActivity",e.getMessage());
        }finally {
            sqLiteDatabase.close();
        }
    }
}
